import 'Vehiculo.dart';

abstract class EstrategiaPersonalizacion {
  void aplicar(Vehiculo vehiculo);
}